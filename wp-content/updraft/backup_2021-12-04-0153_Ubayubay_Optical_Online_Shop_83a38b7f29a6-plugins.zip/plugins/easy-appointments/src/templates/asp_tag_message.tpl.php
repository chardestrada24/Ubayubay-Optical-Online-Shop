<div class="error error-warning">
    <p><strong>EasyAppointments Error Message</strong>. You have APS tags turned on inside yours PHP settings. Please turn it off before you continue with using EasyAppointments. ASP tags are deprecated option and it is removed in latest version of PHP (7.0). More details on <a
            href="https://easy-appointments.net/faq/#blank-admin-pages"
            target="_blank">LINK</a></p>
</div>