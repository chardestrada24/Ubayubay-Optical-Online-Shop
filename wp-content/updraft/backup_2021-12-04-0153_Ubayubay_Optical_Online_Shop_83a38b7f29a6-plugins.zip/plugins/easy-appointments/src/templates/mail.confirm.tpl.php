<div>
    <p><?php _e('Do you want to Confirm appointment?', 'easy-appointments');?></p>
    <form method="post">
        <input name="confirmed" type="hidden" value="true">
        <button class="button button-primary"><?php _e('Yes, I want to Confirm appointment.', 'easy-appointments');?></button>
    </form>
</div>